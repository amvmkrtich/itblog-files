<?php

$array = array('Վարդան Մամիկոնյան', 'Մուշեղ Մամիկոնյան', 'Մոնթե Մելքոնյան', 'Արամ Մանուկյան');
if (isset($_POST['value']) && $_POST['value'] !== '' && isset($array[intval($_POST['value'])])) {
    echo $array[$_POST['value']];
} else {
    echo 'Նման անդամ գոյություն չունի զանգվածի մեջ';
}
?>
