jQuery(document).ready(function ($) {
    $('#request').click(function () {
        $.ajax({
            type: 'POST',
            url: 'index.php',
            data: {
                value: $('#number').val()
            }
        }).done(function (response) {
            $('#success').html(response);
        }).fail(function (jqXHR, statusText, error){
           $('#fail').html(statusText + '<br />' + error); 
        });
    });
});